from modelo_susceptibilidad.msi import msi
from modelo_susceptibilidad.msi_2 import msi_2
from modelo_susceptibilidad.msi import FI
